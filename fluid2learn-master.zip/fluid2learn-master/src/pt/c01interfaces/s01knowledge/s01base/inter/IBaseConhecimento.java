package pt.c01interfaces.s01knowledge.s01base.inter;


public interface IBaseConhecimento
{
	/* Lista o nome de todos os animais cujos arquivos correspondentes encontram-se no pacote db */
    public String[] listaNomes();
    
    /* Recupera o arquivo texto de um determinado animal e o carrega em um objeto que implementa
     * a interface IObjetoConhecimento */
	public IObjetoConhecimento recuperaObjeto(String nome);
}