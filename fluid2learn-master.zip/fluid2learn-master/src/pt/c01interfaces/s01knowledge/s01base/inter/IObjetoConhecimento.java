package pt.c01interfaces.s01knowledge.s01base.inter;

/* Conjunto de objetos que implementa a interface IDeclaracao */
public interface IObjetoConhecimento
{
	public IDeclaracao primeira();

	public IDeclaracao proxima();
}