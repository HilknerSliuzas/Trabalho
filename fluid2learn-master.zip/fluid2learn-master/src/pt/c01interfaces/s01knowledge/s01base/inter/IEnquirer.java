package pt.c01interfaces.s01knowledge.s01base.inter;

public interface IEnquirer
{
	/* Este m�todo recebe como par�metro um objeto que implemente a
	 * interface IResponder, e tem como �nico objetivo conectar o
	 * entrevistador ao entrevistado, iniciando a sequ�ncia de perguntas
	 * que deve levar o entrevistador a identificar qual o animal o
	 * entrevistado escolheu. Ao final, este m�todo deve utilizar-se do
	 * m�todo finalAnswer dispon�vel em IResponder para verificar o acerto
	 * ou o erro por parte do entrevistador. */
    public void connect(IResponder responder);
}
