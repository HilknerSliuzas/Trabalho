package pt.c01interfaces.s01knowledge.s01base.inter;

/* Fornece m�todos para leitura de propriedades (perguntas) e valores (respostas) de
 * cada uma das declara��es presentes nos arquivos textos que descrevem os animais */
public interface IDeclaracao
{
	public String getPropriedade();

	public String getValor();
	
	public String toString();
}