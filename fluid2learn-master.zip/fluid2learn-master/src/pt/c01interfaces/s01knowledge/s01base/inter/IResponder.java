package pt.c01interfaces.s01knowledge.s01base.inter;


public interface IResponder
{
	/* Este m�todo recebe como par�metro uma string correspondente a alguma
	 * propriedade (pergunta) que pode ou n�o estar presente no arquivo que
	 * descreve o animal escolhido pelo entrevistado, e retorna uma string
	 * contendo um de tr�s valores poss�veis: �sim� , �nao� ou �nao sei�. As
	 * duas primeiras respostas s�o definidas no caso em que a propriedade
	 * encontra-se no arquivo do animal em quest�o. A terceira resposta �
	 * utilizada caso contr�rio. */
    public String ask(String question);
    
    /* Este m�todo pode ser invocado apenas uma vez, recebendo como par�metro
     * uma string identificando o animal que o entrevistador julga ser o animal
     * escolhido pelo entrevistado. O m�todo retorna um valor booleano indicando
     * o acerto ou erro por parte do entrevistador. Este m�todo s� poder� ser
     * acionado uma �nica vez ao final da entrevista. */
    public boolean finalAnswer(String answer);
}
